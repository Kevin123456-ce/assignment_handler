/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab8;

import java.math.BigDecimal;

/**
 *
 * @author Admin
 */
public class Calculator{
    private String first="1",second="1",result;
    private char operator='+';
    public void setOperator(char operator){
        this.operator = operator;
    }
    public void setFirst(String first){
        this.first = first;
    }
    public void setSecond(String second){
        this.second=second;
    }
    public char getOperator(){
        return operator;
    }
    public String getFirst(){
        return first;
    }
    public String getSecond(){
        return second;
    }
    public String getResult(){
        return result;
    }
    public void calculate(){
        BigDecimal f = new BigDecimal(this.first);
        BigDecimal s = new BigDecimal(this.second);
        switch (operator) {
            case '+':
                result = f.add(s).toString();
                break;
            case '-':
                result = f.subtract(s).toString();
                break;
            case '*':
                result = f.multiply(s).toString();
                break;
            case '/':
                if(s.doubleValue()==0){
                    result = "Error";
                }
                else{
                    result = f.divide(s,10,BigDecimal.ROUND_HALF_DOWN).toString();
                }
                break;
            default:
                break;
        }
    }
}
