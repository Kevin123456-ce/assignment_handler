/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7;
import java.io.*;
import java.util.*;
/**
 *
 * @author Admin
 */
public class Directory {
    public static void displayAllFiles(File[] files)
    {
        for(File s: files)
        {
            if(s.isDirectory())
            {
                System.out.println(s.getName());
               // System.out.println("");
                File[] f = s.listFiles();
                displayAllFiles(f);
            }
            else
                System.out.println("     "+s.getName());
        }
    }
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a absolute path of directory:");
        String path = sc.next();
        File d = new File(path);
        if(d.exists())
        {
            File[] files = d.listFiles();
            displayAllFiles(files);        
        }
        else
        {
            System.out.println("Given path is not exist!!!");
        }
    }
}
