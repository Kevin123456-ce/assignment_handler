/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7;
import java.util.*;
/**
 *
 * @author Admin
 */
public class Students{
    int id=1;
    String name;
    Students(int id,String name)
    {
        this.id = id;
        this.name = name;
    }
    public String toString()
    {
      return "Id="+id +" Name="+name;   
    }
}
class StudentsComparator implements Comparator<Students>{
    public int compare(Students s1,Students s2)
    {
        if(s1.name.compareTo(s2.name)==0)
        {
            if(s1.id>s2.id)
                return 1;
            else if(s1.id<s2.id)
                return -1;
            else
                return 0;
        }
        return s1.name.compareTo(s2.name);
    }
}
class StudentsDemo{
    public static void main(String[] args){
      Students[] st = {new Students(1,"Jaydev"),new Students(5,"Ronak"),new Students(4,"Ramesh"),
                       new Students(7,"Jenil"),new Students(10,"Mahesh")};
      List<Students> std = new LinkedList<>();
      std.addAll(Arrays.asList(st));
      Collections.sort(std, new StudentsComparator());
      System.out.println("Sorted Students List: "+std);
    }
}