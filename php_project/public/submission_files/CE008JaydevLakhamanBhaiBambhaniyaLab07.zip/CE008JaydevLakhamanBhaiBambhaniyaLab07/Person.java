/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7;
import java.util.*;
/**
 *
 * @author Admin
 */
public class Person {
    String name;
    int age;
    Person(String name,int age)
    {
        this.name = name;
        this.age = age;
    }
    public String toString()
    {
        return "[name="+name+" Age="+age+"]";
    }
}
class PersonHobby
{
    public static void main(String[] args)
    {
        Map<Person,String> ph = new HashMap();
        Person[] p ={new Person("Bhairavi",22),new Person("Dhara",23),new Person("Anmol",23),new Person("Megh",21),new Person("Raag",22)};
        String[] hobby={"Singing","Sketching","Reading","Singing","Sketching"};
        for(int i=0;i<5;i++)
        {
            ph.put(p[i], hobby[i]);
        }
        System.out.println("Elements in Map: ");
        System.out.println(ph);
        Set<String> unique = new HashSet<>();
        for(int i=0;i<5;i++)
        {
            String h = ph.get(p[i]);
            if(!unique.contains(h))
                unique.add(h);
        }
        System.out.println("Unique: "+unique);
    }
}
