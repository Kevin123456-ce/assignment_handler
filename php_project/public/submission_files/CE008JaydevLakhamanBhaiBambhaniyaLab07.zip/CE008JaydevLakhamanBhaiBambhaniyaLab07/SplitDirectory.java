/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7;
import java.util.*;
import java.io.*;
/**
 *
 * @author Admin
 */
public class SplitDirectory {
    public static void main(String[] args) throws IOException{
        Scanner sc = new Scanner(System.in); 
       File src = new File("D:\\Java\\Source");
       src.mkdir();
       File dest = new File("D:\\Java\\Destination");
       dest.mkdir();
       RandomAccessFile raf = new RandomAccessFile("D:\\Java\\Source\\src_file.txt","rw");
       long size = raf.length();
       long parts = size/(5*1024);
       long remaining = size%(5*1024);
       long i;
       for(i=1;i<=parts+1;i++)
       {
            BufferedOutputStream bs = new BufferedOutputStream(new FileOutputStream("D:\\Java\\Destination\\part"+i+".txt"));
            byte[] w = new byte[(int)5120];
            int v = raf.read(w);
            if(v!=-1)
              bs.write(w);
            bs.close();
       }
       raf.close();    
    }
}
